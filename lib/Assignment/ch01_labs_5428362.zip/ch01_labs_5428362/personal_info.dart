void main(List<String> args) {
  print("*************************************\n");
  print("Name: Doyun Kim\n");
  print("ID: 5428362\n");
  print("Phone: 010 3561 4217\n");
  print("Department: College of Engineering\n");
  print("Grade: 4\n");
  print("*************************************\n");
}
